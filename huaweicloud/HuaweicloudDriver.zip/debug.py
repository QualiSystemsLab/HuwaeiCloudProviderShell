import cloudHandler
import json
import driver
import cloudshell.helpers.scripts.cloudshell_dev_helpers as dev_help
import cloudshell.helpers.scripts.cloudshell_scripts_helpers as script_help
from cloudshell.shell.core.driver_context import InitCommandContext, AutoLoadCommandContext, ResourceCommandContext, \
    AutoLoadAttribute, AutoLoadDetails, CancellationContext, ResourceRemoteCommandContext
from cloudshell.shell.core.resource_driver_interface import ResourceDriverInterface

# Debug Script

# HWC = cloudHandler.huawei_cloud_provider(
#     username="QualiCS_HC",
#     password="quali1@3456",  # decrypt!
#     projectId="46fac4b596c142e9984fb8dfb109c8cb",
#     userDomainId="b739ccf8e6aa4a268c0a51c95484a655"
# )
# new_server = HWC.create_vm(name='my_hwc_server' ,image='292a7f86-3f3e-44b0-8ed5-3f244a07a563')
# new_ip = HWC.createEIP(HWC.get_vm_port_id(new_server))
# HWC.delete_vm(new_server)

dev_help.attach_to_cloudshell_as(
    user='admin',
    password='admin',
    domain='Global',
    reservation_id='c3f09270-58a6-4188-a11d-19239d73a0d8',
    server_address='192.168.85.15',
    resource_name='HWC'

)
driver_interface = ResourceDriverInterface


context = ResourceCommandContext(
    connectivity=script_help.get_connectivity_context_details(),
    reservation=script_help.get_reservation_context_details(),
    resource=script_help.get_resource_context_details(),
    connectors=None
)
with open('request.json', 'r') as file:
    my_request = json.load(file)

my_hwc_driver = driver.HuaweicloudDriver()
my_hwc_driver.initialize(context)
my_hwc_driver.Deploy(context, request=my_request)
pass

# self.username = "QualiCS_HC"
# self.password = "quali1@3456"
# self.projectId = "46fac4b596c142e9984fb8dfb109c8cb"    # tenant ID
# self.userDomainId = "b739ccf8e6aa4a268c0a51c95484a655"    # user account ID